import pandas as pd

from src.data_loader import coerce_multi_select_series, process_dataframe
from src.data_processor import process_multi_select_question


def test_string_multiselect_values_do_not_concatenate_during_sum():
    """Regression test for TypeError: unsupported operand type(s) for /: 'str' and 'int'."""
    col = "Q(2_1) Apple[Question: Pick all that apply]"
    df = pd.DataFrame({col: ["Apple", "", None, "Apple"]})

    assert process_multi_select_question(df, "2", ["Apple"]) == [0.5]


def test_multiselect_normalisation_handles_common_export_encodings():
    cases = [
        ([True, False, True], 2),
        ([1, 0, 1], 2),
        (["TRUE", "FALSE", "TRUE"], 2),
        (["1.0", "0.0", "1.0"], 2),
        (["Apple", "", "Apple"], 2),
        (["Apple; Banana", "", "Banana"], 1),
    ]

    for raw_values, expected_count in cases:
        selected = coerce_multi_select_series(pd.Series(raw_values), "Apple")
        assert int(selected.sum()) == expected_count


def test_string_dtype_multiselect_columns_are_normalised_by_loader():
    col = "Q(2_1) Apple[Question: Pick all that apply]"
    df = pd.DataFrame(
        {
            col: pd.Series(["Apple", "", None], dtype="string"),
            "Q(3) Single question": ["A", "B", "C"],
        }
    )

    processed = process_dataframe(df)

    assert processed[col].dtype == bool
    assert processed[col].tolist() == [True, False, False]
